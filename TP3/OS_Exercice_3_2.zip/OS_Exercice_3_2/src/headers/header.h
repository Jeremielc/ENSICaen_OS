#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include <string.h>

typedef struct data {
    char* name;
    int n;
} DATA;

#endif	// HEADER_H

