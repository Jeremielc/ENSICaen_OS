/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 11 juin 2016, 23:59
 */

#include "headers/header.h"

int rank = 1;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* counting(void* arg) {
    DATA* data = (DATA*) arg;
    int time_sleeping;
    
    for (int i = 0; i < data->n; i++) {
        time_sleeping = rand()  % 3 + 1;
        printf("%s : %d\n", data->name, i);
        sleep(time_sleeping);
    }
    
    pthread_mutex_lock(&mutex);
    printf("%s a fini de compter jusqu'a : %d en position %d\n", data->name, data->n, rank);
    rank += 1;
    pthread_mutex_unlock(&mutex);
    
    pthread_exit(NULL);
}

int main(int argc, char** argv) {
    int init = pthread_mutex_init(&mutex, NULL);
    if (init != 0) {
        printf("%s\n", "Création de mutex impossible");
        exit(0);
    }
    
    pthread_t counter_1, counter_2, counter_3;
    char* counter_1_name = "counter 1";
    char* counter_2_name = "counter 2";
    char* counter_3_name = "counter 3";
    
    srand(time(NULL));
    
    DATA one = {counter_1_name, 5};
    DATA two = {counter_2_name, 5};
    DATA three = {counter_3_name, 5};

    pthread_create(&counter_1, NULL, counting, (void*) &one);
    pthread_create(&counter_2, NULL, counting, (void*) &two);
    pthread_create(&counter_3, NULL, counting, (void*) &three);

    pthread_join(counter_1, NULL);
    pthread_join(counter_2, NULL);
    pthread_join(counter_3, NULL);

    pthread_mutex_destroy(&mutex);

    return (EXIT_SUCCESS);
}

