/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 11 juin 2016, 23:59
 */

#include "headers/header.h"

int count = 0;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void * counting(void * arg) {
    int i, a;

    for (i = 0; i < 1000000; i++) {
        pthread_mutex_lock(&mutex);
        
        a = count;
        a *= 3;
        a = (a / 3) + 1;
        count = a;
        
        pthread_mutex_unlock(&mutex);
    }

    return 0;
}

int main(int argc, char** argv) {
    int init = pthread_mutex_init(&mutex, NULL);
    if (init != 0) {
        printf("%s\n", "Création de mutex impossible");
        exit(0);
    }
    
    int res1, res2;
    pthread_t a_thread1, a_thread2;
    void *thread_result1, *thread_result2;

    res1 = pthread_create(&a_thread1, NULL, counting, NULL);
    res2 = pthread_create(&a_thread2, NULL, counting, NULL);

    printf("On attend la fin des threads\n");
    pthread_join(a_thread1, &thread_result1);
    pthread_join(a_thread2, &thread_result2);

    printf("count = %d\n", count);

    pthread_mutex_destroy(&mutex);

    return (EXIT_SUCCESS);
}

