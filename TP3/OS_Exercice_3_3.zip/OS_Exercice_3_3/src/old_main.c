/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 11 juin 2016, 23:59
 */

#include "headers/header.h"

double** alloc_matrix(unsigned int rows, unsigned int columns) {
    double **matrix;
    unsigned int row;

    matrix = (double**) calloc(rows, sizeof (double*));
    if (!matrix) {
        return NULL;
    }

    matrix[0] = (double*) calloc(rows * columns, sizeof (double));
    if (!matrix[0]) {
        free(matrix);
        return NULL;
    }

    for (row = 1; row < rows; ++row) {
        matrix[row] = matrix[row - 1] + columns;
    }

    return matrix;
}

void free_matrix(double** matrix) {
    free(matrix[0]);
    free(matrix);
}

void random_matrice(double** matrix, unsigned int rows, unsigned int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            matrix[j][i] = (rand() % 10000) / 100.0;
        }
    }
}

void printMatrix(double** matrix, unsigned int rows, unsigned int columns) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            printf("%.3lf | ", matrix[j][i]);
        }
        printf("\n");
    }
}

double** old_product(double** matrix_1, double** matrix_2, unsigned int size) {
    double** resMat = alloc_matrix(size, size);

    double res = 0;
    for (int y = 0; y < size; y++) {
        for (int x = 0; x < size; x++) {
            res = 0;
            
            for (int k = 0; k < size; k++) {
                res += matrix_1[y][k] * matrix_2[k][x];
            }

            resMat[x][y] = res;
        }
    }

    return resMat;
}

void* new_product(void* data) {
    DATA_PRODUCT* temp = (DATA_PRODUCT*) data;
    double** resMat = alloc_matrix(temp->size, temp->size);

    double res = 0;
    for (int y = 0; y < temp->size; y++) {
        for (int x = 0; x < temp->size; x++) {
            res = 0;
            
            for (int k = 0; k < temp->size; k++) {
                res += temp->matrix_1[y][k] * temp->matrix_2[k][x];
            }

            resMat[x][y] = res;
        }
    }

    temp->resMat = resMat;
    pthread_exit(NULL);
}

double** product_threaded(double** matrix_1, double** matrix_2, unsigned int size) {
    pthread_t t1, t2, t3, t4;
    int length = size / 2;
    
    double** matrix_1_1, **matrix_1_3, **matrix_1_2, **matrix_1_4;    // x_1      x_2
    double** matrix_2_1, **matrix_2_3, **matrix_2_2, **matrix_2_4;    // x_3      x_4
    
    matrix_1_1 = alloc_matrix(length, length);
    matrix_2_1 = alloc_matrix(length, length);
    for (int y = 0; y < length; y++) {
        for (int x = 0; x < length; x++) {
            matrix_1_1[y][x] = matrix_1[y][x];
            matrix_2_1[y][x] = matrix_2[y][x];
        }
    }
    
    matrix_1_2 = alloc_matrix(length, length);
    matrix_2_2 = alloc_matrix(length, length);
    for (int y = 0; y < length; y++) {
        for (int x = 0; x < length; x++) {
            matrix_1_2[y][x] = matrix_1[y + length][x];
            matrix_2_2[y][x] = matrix_2[y + length][x];
        }
    }
    
    matrix_1_3 = alloc_matrix(length, length);
    matrix_2_3 = alloc_matrix(length, length);
    for (int y = 0; y < length; y++) {
        for (int x = 0; x < length; x++) {
            matrix_1_3[y][x] = matrix_1[y][x + length];
            matrix_2_3[y][x] = matrix_2[y][x + length];
        }
    }
    
    matrix_1_4 = alloc_matrix(length, length);
    matrix_2_4 = alloc_matrix(length, length);
    for (int y = 0; y < length; y++) {
        for (int x = 0; x < length; x++) {
            matrix_1_4[y][x] = matrix_1[y + length][x + length];
            matrix_2_4[y][x] = matrix_2[y + length][x + length];
        }
    }
    
    DATA_PRODUCT one    =   {matrix_1_1, matrix_2_1, NULL, length};
    DATA_PRODUCT two    =   {matrix_1_2, matrix_2_2, NULL, length};
    DATA_PRODUCT three  =   {matrix_1_3, matrix_2_3, NULL, length};
    DATA_PRODUCT four   =   {matrix_1_4, matrix_2_4, NULL, length};
    
    pthread_create(&t1, NULL, new_product, (void*) &one);
    pthread_create(&t2, NULL, new_product, (void*) &two);
    pthread_create(&t3, NULL, new_product, (void*) &three);
    pthread_create(&t4, NULL, new_product, (void*) &four);
    
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    pthread_join(t4, NULL);
    
    double** resMat = alloc_matrix(size, size);
    
    for (int y = 0; y < length; y++) {
        for (int x = 0; x < length; x++) {
            resMat[y][x] = one.resMat[y][x];
            resMat[y][x + length] = three.resMat[y][x];
            resMat[y + length][x] = two.resMat[y][x];
            resMat[y + length][x + length] = four.resMat[y][x];
        }
    }
    
    printMatrix(resMat, size, size);
}

int main(int argc, char** argv) {
    double **matrix_1, **matrix_2;
    int size = 2000;   //Les matrice doivent etre de dimension paire.

    srand(time(NULL));

    printf("##### Matrix 1 #####\n");
    matrix_1 = alloc_matrix(size, size);
    random_matrice(matrix_1, size, size);
    printMatrix(matrix_1, size, size);
    printf("####################\n\n");

    printf("##### Matrix 2 #####\n");
    matrix_2 = alloc_matrix(size, size);
    random_matrice(matrix_2, size, size);
    printMatrix(matrix_2, size, size);
    printf("####################\n\n");

    double** resMat = old_product(matrix_1, matrix_2, size);

    printf("##### Result Mat 1 #####\n");
    printMatrix(resMat, size, size);
    printf("########################\n\n");
    
    printf("##### Result Mat 2 #####\n");
    product_threaded(matrix_1, matrix_2, size);
    printf("########################\n");

    free_matrix(matrix_1);
    free_matrix(matrix_2);
    free_matrix(resMat);

    return (EXIT_SUCCESS);
}

