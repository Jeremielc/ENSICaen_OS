#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>

#define NBTHREAD 4
#define MAXVAL 9999
#define MAT_SIZE 1000   //La matrice doit etre de taille paire

typedef struct thread_Args {
    int rowFrom;
    int rowTo;
    double** matrix_1;
    double** matrix_2;
    double** resMat;
    unsigned int rows_1;
    unsigned int columns_1;
    unsigned int rows_2;
    unsigned int columns_2;
} THREAD_ARGS;

#endif // HEADER_H

