#include "headers/header.h"

double** alloc_matrix(unsigned int rows, unsigned int columns) {
    double** matrix = (double**) calloc(rows, sizeof (double*));
    if (!matrix) {
        return NULL;
    }

    for (int i = 0; i < rows; i++) {
        matrix[i] = (double*) calloc(columns, sizeof (double));
    }

    return matrix;
}

void free_matrix(double** matrix) {
    free(matrix[0]);
    free(matrix);
}

void random_matrix(double*** matrix, unsigned int rows, unsigned int columns) {
    for (int y = 0; y < rows; y++) {
        for (int x = 0; x < columns; x++) {
            (*matrix)[y][x] = rand() % MAXVAL;
        }
    }
}

void* product_thread(void* arg) {
    THREAD_ARGS* argsThread = (THREAD_ARGS*) arg;
    for (int y = argsThread->rowFrom; y < argsThread->rowTo; y++) {
        for (int x = 0; x < argsThread->columns_2; x++) {
            for (int k = 0; k < argsThread->rows_2; k++) {
                argsThread->resMat[y][x] += argsThread->matrix_1[y][k] * argsThread->matrix_2[k][x];
            }
        }
    }

    return NULL;
}

double** product(double** matrix_1, unsigned int rows_1, unsigned int columns_1, double** matrix_2, unsigned int rows_2, unsigned int columns_2) {
    double** resMat = alloc_matrix(columns_2, rows_1);

    for (int y = 0; y < rows_1; y++) {
        for (int x = 0; x < columns_2; x++) {
            for (int k = 0; k < rows_2; k++) {
                resMat[y][x] += matrix_1[y][k] * matrix_2[k][x];
            }
        }
    }

    return resMat;
}

void print_matrix(double** matrix, unsigned int rows, unsigned int columns) {
    for (int y = 0; y < rows; y++) {
        for (int x = 0; x < columns; x++) {
            printf("%.3f | ", matrix[y][x]);
        }
        printf("\n");
    }
}

int main(int argc, char** argv) {
    int resThread[NBTHREAD];
    pthread_t threadTab[NBTHREAD];
    void* threadResults[NBTHREAD];
    THREAD_ARGS argsTab[NBTHREAD];
    clock_t startClock;
    clock_t endClock;
    time_t startTime;
    time_t endTime;
    int spaceLength;

    double** matrix_1 = alloc_matrix(MAT_SIZE, MAT_SIZE);
    double** matrix_2 = alloc_matrix(MAT_SIZE, MAT_SIZE);
    double** resMat = alloc_matrix(MAT_SIZE, MAT_SIZE);

    srand(time(NULL));
    random_matrix(&matrix_1, MAT_SIZE, MAT_SIZE);
    random_matrix(&matrix_2, MAT_SIZE, MAT_SIZE);

    printf("Produit matriciel classique : \n");
    startClock = clock();
    startTime = time(NULL);

    resMat = product(matrix_1, MAT_SIZE, MAT_SIZE, matrix_2, MAT_SIZE, MAT_SIZE);

    endClock = clock();
    endTime = time(NULL);

    printf("Clock : Avec un seul thread il faut : %f secondes\n", ((double) (endClock - startClock) / CLOCKS_PER_SEC));
    printf("Time : Avec un seul thread il faut : %f secondes\n\n", difftime(endTime, startTime));

    //Séparation du calcul
    spaceLength = MAT_SIZE / NBTHREAD;

    printf("Produit matriciel multithreadé :\n");
    startClock = clock();
    startTime = time(NULL);

    //Parametrage des threads
    for (int i = 0; i < NBTHREAD; i++) {
        argsTab[i].rowFrom = i * spaceLength;
        argsTab[i].rowTo = (i + 1) * spaceLength;

        argsTab[i].matrix_1 = matrix_1;
        argsTab[i].rows_1 = MAT_SIZE;
        argsTab[i].columns_1 = MAT_SIZE;

        argsTab[i].matrix_2 = matrix_2;
        argsTab[i].rows_2 = MAT_SIZE;
        argsTab[i].columns_2 = MAT_SIZE;

        argsTab[i].resMat = resMat;
    }

    //Lancement des threads
    for (int i = 0; i < NBTHREAD; i++) {
        resThread[i] = pthread_create(&threadTab[i], NULL, product_thread, &argsTab[i]);
    }

    //Attente de la fin des threads
    for (int i = 0; i < NBTHREAD; i++) {
        pthread_join(threadTab[i], &threadResults[i]);
    }

    endClock = clock();
    endTime = time(NULL);

    printf("Clock : Avec %d threads il faut : %f secondes\n", NBTHREAD, ((double) (endClock - startClock) / CLOCKS_PER_SEC));
    printf("Time : Avec %d threads il faut : %f secondes\n", NBTHREAD, difftime(endTime, startTime));

    free_matrix(matrix_1);
    free_matrix(matrix_2);
    free_matrix(resMat);

    return EXIT_SUCCESS;
}
