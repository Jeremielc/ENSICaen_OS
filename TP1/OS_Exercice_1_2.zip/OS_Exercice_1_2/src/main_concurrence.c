/*
* File:   main_save.c
* Author: Jérémie Leclerc : jeremie.leclerc@fime.com
*
* Created on 24 mai 2016, 14:36
*/

#include "headers/header.h"

int main(int argc, char** argv) {
    int pid_filsDate = 0;
    int pid_filsAttente = 0;

    if (fork() == 0) {
        for (int i = 0; i < 10; i++) {
            sleep(3);
            pid_filsDate = fork();

            if (pid_filsDate == 0) {
                execl("/bin/date", "date", "-u", NULL);
                //execl ecrase le processus qui l'a lancé.
                //Les petits fils ne crééront pas d'autres processus.
            }
        }
    }

    if (fork() == 0) {
        for (int i = 0; i < 30; i++) {
            sleep(2);
            pid_filsAttente = fork();

            if (pid_filsAttente == 0) {
                printf("Attendre\n");
                break;  //Seul le fils parcours la boucle, pas les petits fils.
            }
        }
    }

    while(wait(NULL) > -1) {}
}
