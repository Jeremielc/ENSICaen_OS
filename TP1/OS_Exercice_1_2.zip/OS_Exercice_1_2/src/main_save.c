/*
 * File:   main_save.c
 * Author: Jérémie Leclerc : jeremie.leclerc@fime.com
 *
 * Created on 24 mai 2016, 14:36
 */

#include "headers/header.h"

int main(int argc, char** argv) {
    int date_index = 0, att_index = 0;
    int pid_filsDate = 0, pid_filsAttente = 0;

    while (date_index < 10) {
        pid_filsDate = fork();

        if (pid_filsDate == 0) {
            execl("/bin/date", "date", "-u", NULL);
            //exel ecrase le processus qui l'a lancé.
        } else {
            while (att_index < 30) {
                pid_filsAttente = fork();

                if (pid_filsAttente == 0) {
                    printf("%s\n", "Attendre");
                } else {
                    wait(&pid_filsAttente);
                }

                att_index += 1;
                sleep(2);
            }
        }

        date_index += 1;
        sleep(3);
    }
}
