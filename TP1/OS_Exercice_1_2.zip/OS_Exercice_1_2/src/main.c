/*
* File:   main_save.c
* Author: Jérémie Leclerc : jeremie.leclerc@fime.com
*
* Created on 24 mai 2016, 14:36
*/

#include "headers/header.h"

int main(int argc, char** argv) {
    int pid_filsDate = 0;
    int pid_filsAttente = 0;

    FILE* canal;
    canal = fopen("message.log", "wt");
    if (canal == NULL) {
        printf("%s\n", "Impossible d'ouvrir le fichier message.log");
        exit(0);
    }

    pid_filsDate = fork();
    if (pid_filsDate == 0) {
        for (int i = 0; i < 10; i++) {
            sleep(3);
            pid_filsDate = fork();

            dup2(canal->_fileno, 1);
            //Redirection de la sortie standard vers message.log.

            if (pid_filsDate == 0) {
                execl("/bin/date", "date", "-u", NULL);
                //execl ecrase le processus qui l'a lancé.
                //Les petits fils ne crééront pas d'autres processus.
            }
        }

        close(canal->_fileno);
        exit(1);
    }

    pid_filsAttente = fork();
    if (pid_filsAttente == 0) {
        for (int i = 0; i < 30; i++) {
            sleep(2);
            pid_filsAttente = fork();

            dup2(canal->_fileno, 1);
            //Redirection de la sortie standard vers message.log.

            if (pid_filsAttente == 0) {
                printf("Attendre\n");
                break; //Seul le fils parcours la boucle, pas les petits fils.
            }
        }

        close(canal->_fileno);
        exit(2);
    }

    while (wait(NULL) > -1) {

    }

    dup2(canal->_fileno, 1);
    printf("%s\n", "C'est terminé !");
    close(canal->_fileno);
    fclose(canal);
}
