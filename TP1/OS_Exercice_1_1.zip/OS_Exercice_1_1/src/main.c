/*
 * File:   main.c
 * Author: Jérémie Leclerc : jeremie.leclerc@fime.com
 *
 * Created on 24 mai 2016, 14:36
 */

#include "headers/header.h"

int main(int argc, char** argv) {
    printf("Programme principal\n");
    int pid = fork();

    if (pid == -1) {
        printf("Fork impossible\n");
    } else if (pid == 0) {
        //Le processus fils desire mourir mais doit attendre que son pere
        //recuperer son état pour se terminer.
        printf("Processus fils\n");
        exit(0);
    } else {
        //Le processus pere ne pourra pas recuperer l'etat du processus fils
        //pour que celui-ci puisse se terminer.
        printf("Processus père\n");
        pause();
    }

    return (EXIT_SUCCESS);
}
