/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 31 mai 2016, 10:11
 */

#include "headers/header.h"

int main(void) {
    int tube_pere_fils[2];
    int tube_fils_pere[2];
    if (pipe(tube_pere_fils) == 1 || pipe(tube_fils_pere)) {
        perror("Pipes invalides\n");
        exit(0);
    }

    char* output = (char*) malloc(BUFF_SIZE * sizeof (char));
    char* input = (char*) malloc(BUFF_SIZE * sizeof (char));
    clearBuffer(input);
    clearBuffer(output);

    pid_t pid = fork();

    if (pid == -1) {
        perror("Fork impossible\n");
    } else if (pid == 0) {
        close(tube_fils_pere[0]);
        close(tube_pere_fils[1]);
        
        do {
            read(tube_pere_fils[0], input, BUFF_SIZE);

            int i = 0;
            for (i = 0; i < strlen(input); i++) {
                output[i] = toupper(input[i]);
            }
            output[i] = '\0';

            write(tube_fils_pere[1], output, strlen(input) + 1);
        } while (input[0] != 'q' && input[1] != 'u' && input[2] != 'i' && input[3] != 't'); //Detection de "quit"
    } else {
        close(tube_pere_fils[0]);
        close(tube_fils_pere[1]);
        
        do {
            printf("String to transform : ");
            fgets(output, BUFF_SIZE, stdin);

            if (output[0] == 'q' && output[1] == 'u' && output[2] == 'i' && output[3] == 't') { //Detection de "quit"
                write(tube_pere_fils[1], output, strlen(output) + 1);
                break;
            }

            write(tube_pere_fils[1], output, strlen(output) + 1);
            read(tube_fils_pere[0], input, strlen(output) + 1);
            
            printf("-> %s\n", input);
        } while (strcmp(output, "quit") != 0);
    }

    return EXIT_SUCCESS;
}

void clearBuffer(char* buff_out) {
    for (int i = 0; i < BUFF_SIZE; i++) {
        buff_out[i] = '\0';
    }
}