/*
 * File:   main.c
 * Author: jeremie
 *
 * Created on 10 juin 2016, 08:25
 */

#include "headers/header.h"

int main(int argc, char** argv) {
    key_t semKey = ftok(argv[0], 'E');
    int semid = semget(semKey, 7, IPC_CREAT | IPC_EXCL | 0600);
    if (semid == -1) {
        printf("%s\n", "Creation de semaphore impossible.");
        exit(0);
    }

    semctl(semid, 0, SETVAL, 1); //fourchette 0
    semctl(semid, 1, SETVAL, 1); //fourchette 1
    semctl(semid, 2, SETVAL, 1); //fourchette 2
    semctl(semid, 3, SETVAL, 1); //fourchette 3
    semctl(semid, 4, SETVAL, 1); //fourchette 4

    semctl(semid, 5, SETVAL, 1); //Gestion de l'acces à la ressource partagée
    semctl(semid, 6, SETVAL, 1); //Gestion de l'acces à l'affichage.

    int shmKey = ftok(argv[0], 'J');
    int shmid = shmget(shmKey, 6 * sizeof (char), IPC_CREAT | 0600);
    if (shmid == -1) {
        printf("%s\n", "Creation de shmem impossible.");
        exit(0);
    }

    //Obtention des informations
    printf("semid : %d\n", semid);
    printf("shmid : %d\n\n", shmid);
    fflush(stdout);

    char* philStatus = shmat(shmid, NULL, SHM_R | SHM_W);
    for (int i = 0; i < 5; i++) {
        philStatus[i] = THINK;
    }
    philStatus[5] = '\0';

    pid_t pid;

    for (int i = 0; i < 5; i++) {
        pid = fork();
        srand(time(NULL) + getpid());

        if (pid == -1) {
            printf("%s\n", "Fork impossible.");
            exit(-1);
        } else if (pid == 0) {
            int count = 3;

            while (count > 0) {
                thinkAskEatRepeat(semid, i, philStatus);
                count--;
            }
            
            printPhilState(semid, i, philStatus);

            exit(1);
        }
    }

    for (int i = 0; i < 5; i++) {
        wait(NULL);
    }

    semctl(semid, 0, IPC_RMID, 0);
    shmctl(shmid, IPC_RMID, NULL);
    return (EXIT_SUCCESS);
}

void Probeer_one(int semid, int num) {
    struct sembuf op;
    op.sem_flg = 0;
    op.sem_num = num;
    op.sem_op = -1;

    semop(semid, &op, 1);
}

void Verhoog_one(int semid, int num) {
    struct sembuf op;
    op.sem_flg = 0;
    op.sem_num = num;
    op.sem_op = 1;

    semop(semid, &op, 1);
}

void Probeer_two(int semid, int num_1, int num_2) {
    struct sembuf ops[2];;
    ops[0].sem_flg = 0;
    ops[0].sem_num = num_1;
    ops[0].sem_op = -1;
    
    ops[1].sem_flg = 0;
    ops[1].sem_num = num_2;
    ops[1].sem_op = -1;

    semop(semid, ops, 2);
}

void Verhoog_two(int semid, int num_1, int num_2) {
    struct sembuf ops[2];;
    ops[0].sem_flg = 0;
    ops[0].sem_num = num_1;
    ops[0].sem_op = 1;
    
    ops[1].sem_flg = 0;
    ops[1].sem_num = num_2;
    ops[1].sem_op = 1;

    semop(semid, ops, 2);
}

void printPhilState(int semid, int philNum, char* philStatus) {
    Probeer_one(semid, 6);
    for (int i = 0; i < 5; i++) {
        switch (philStatus[i]) {
            case THINK:
                printf("[%s] Philosophe %d %s\n", philStatus, i, "pense.");
                break;
            case ASK:
                printf("[%s] Philosophe %d %s\n", philStatus, i, "demande à manger.");
                break;
            case EAT:
                printf("[%s] Philosophe %d %s\n", philStatus, i, "mange.");
                break;
        }
        fflush(stdout);
    }

    printf("\n");
    Verhoog_one(semid, 6);
}

/*void checkIfPhilCanEat(int semid, int philNum, char* philStatus) {
    if (philStatus[(philNum + 4) % 5] != EAT) {
        if (philStatus[(philNum + 1) % 5] != EAT) {
            if (philStatus[philNum] == ASK) {
                Verhoog_one(semid, philNum);
            }
        }
    }
}*/

void setPhilState(char* philStatus, int philNum, char state) {
    switch (state) {
        case THINK:
            philStatus[philNum] = THINK;
            break;
        case ASK:
            philStatus[philNum] = ASK;
            break;
        case EAT:
            philStatus[philNum] = EAT;
            break;
        default:
            break;
    }
}

void think(int semid, int philNum, char* philStatus) {
    int timeThinking = rand() % 3 + 1;

    Probeer_one(semid, 5);
    setPhilState(philStatus, philNum, THINK);
    Verhoog_one(semid, 5);
    
    printPhilState(semid, philNum, philStatus);
    sleep(timeThinking);
}

void ask(int semid, int philNum, char* philStatus) {
    Probeer_one(semid, 5);
    setPhilState(philStatus, philNum, ASK);
    Verhoog_one(semid, 5);
    
    printPhilState(semid, philNum, philStatus);
}

void eat(int semid, int philNum, char* philStatus) {
    Probeer_two(semid, (philNum + 4) % 5, philNum);
    int timeEating = rand() % 3 + 1;

    Probeer_one(semid, 5);
    setPhilState(philStatus, philNum, EAT);
    Verhoog_one(semid, 5);
    
    printPhilState(semid, philNum, philStatus);
    sleep(timeEating);

    Probeer_one(semid, 5);
    setPhilState(philStatus, philNum, THINK);
    Verhoog_one(semid, 5);
    Verhoog_two(semid, (philNum + 4) % 5, philNum);
}

void thinkAskEatRepeat(int semid, int philNum, char* philStatus) {
    think(semid, philNum, philStatus);
    ask(semid, philNum, philStatus);
    eat(semid, philNum, philStatus);
}