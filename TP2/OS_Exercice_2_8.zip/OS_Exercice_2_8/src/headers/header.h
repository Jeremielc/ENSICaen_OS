#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <time.h>
#include <ctype.h>
#include <sys/signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>

#define THINK 'T'
#define ASK 'A'
#define EAT 'E'

void    Probeer_one         (int semid, int semNum);   //P = Probeer ('Try')
void    Verhoog_one         (int semid, int semNum);   //V = Verhoog ('Increment', 'Increase by one').
void    Probeer_two         (int semid, int semNum_1, int semNum_2);   //P = Probeer ('Try')
void    Verhoog_two         (int semid, int semNum_1, int semNum_2);   //V = Verhoog ('Increment', 'Increase by one').
void    printPhilState      (int semid, int philNum, char* philStatus);
void    setPhilState        (char* philStatus, int philNum, char state);
void    think               (int semid, int philNum, char* philStatus);
void    ask                 (int semid, int philNum, char* philStatus);
void    eat                 (int semid, int philNum, char* philStatus);
void    thinkAskEatRepeat   (int semid, int philNum, char* philStatus);

#endif	// HEADER_H

