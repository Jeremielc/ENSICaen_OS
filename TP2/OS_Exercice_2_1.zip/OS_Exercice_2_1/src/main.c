/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 30 mai 2016, 11:35
 */

#include "headers/header.h"

int N = 0; //Attention, variable globale !

int main(int argc, char** argv) {
    signal(SIGTERM, handler);   //Assignation d'un handler
    while (1) {
        printf("Toc toc %d\n", N);
        sleep(2);
    }
    
    return (EXIT_SUCCESS);
}

void handler(int sig) {
    if (sig == SIGTERM) {
        N += 1;
        signal(SIGTERM, handler); //Sans cela le programme s'arrete au prochain SIGTERM
    } else if (sig == SIGQUIT) {
        exit(0);
    }
}

