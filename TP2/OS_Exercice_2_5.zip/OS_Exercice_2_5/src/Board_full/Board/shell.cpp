/** 
 * shell_board.c
 * 
 * Programme shell pour le logiciel "board".
 *
 */
#include "shell.h"
#include "DrawingCommands.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

#define MAXLEN 1024

/** 
 * Main loop of the drawing commands intepreter.
 * 
 * @param in 
 * @param out 
 */
void father_process( int in, int out );

/** 
 * Parses a command string and build the corresponding DrawingCommand struct
 * accordingly.
 * 
 * @param string A command string (e.g. "line 10 10 100 150").
 * @param command Address of a structure to be filled.
 * 
 * @return 1 if a valid command has been parsed, otherwise 0.
 */
int parse_command( const char * string, struct DrawingCommand * command );

/** 
 * SIGPIPE signal handler
 * 
 * @param int Num�ro du signal
 */
void on_pipe_closed( int signal ) {
  printf( "The pipe has been closed (SIGPIPE).\n" );
  exit( 0 );
}

/** 
 * Launch the board programm in a child process after setting up
 * two pipes for the communication with this new process.
 */
void shell()
{
  int father_2_son[2];
  int son_2_father[2];
  pid_t pid;
  
  if ( pipe( father_2_son ) ) {
    perror( "pipe()" );
    exit( 1 );
  }  
  if ( pipe( son_2_father ) ) {
    perror( "pipe()" );
    exit( 1 );
  }
  
  pid = fork();

  if ( pid == -1 ) {
    perror( "fork()" );
    exit( 0 );
  }

  if ( pid == 0 ) {
    close( son_2_father[0] );
    dup2( son_2_father[1], 1 );
    close( father_2_son[1] );
    dup2( father_2_son[0], 0 );
    execl( "board","board", "-", NULL );
    perror( "execl()" );
  }
 
  if ( pid > 0 ) {
    int status;
    close( son_2_father[1] );
    close( father_2_son[0] );
    father_process( son_2_father[0], father_2_son[1] );
    wait( &status );
    printf( "Board has ended\n" );
    exit( 0 );
  }
}

/** 
 * Main function of the shell.
 * 
 * @param in Input (write only) of the pipe towards the board process.
 * @param out Output (read only) of the pipe.
 */
void father_process( int in, int out )
{
  char line[MAXLEN] = "";
  char buffer[MAXLEN];
  char *pc;
  struct DrawingCommand command;  

  memset( &command, 0, sizeof( command ) );
  fflush( stdin );
  signal( SIGPIPE, &on_pipe_closed );

  while( command.type != Quit ) {     
    /* Get a string */
    printf("Command> ");
    fflush( stdout );
    
    if ( ! fgets( line, MAXLEN, stdin ) ) {
      if ( feof( stdin ) ) {
	command.type = Quit;
	write( out, &command, sizeof( command ) );
	printf( "EOF\nWaiting for board to terminate...\n" );
      } else { 
	printf( "Terminating!\n" );
      }
      return;
    }
      
    if ( parse_command( line, & command ) ) {
      int n = 0;
      int nb;
      nb = write( out, &command, sizeof( command ) );
      if ( nb <= 0 ) {
	perror( "write()" );
	return;
      }
      /* Extract the answer from the pipe */
      n = 0;
      pc = buffer;
      do {
	pc += n;
	n = read( in, pc, MAXLEN - ( pc - buffer ) );
	pc[n]='\0';
      } while ( pc[n - 1] != '\n' );
      pc[n-1]='\0';
      printf("Board says: \"%s\"\n", buffer );	
    } else {
      printf( "Unrecognized command.\n" );
    }
  }
}

int parse_command( const char * string, struct DrawingCommand * command ) {
  char prefix[1024] = ""; 
  sscanf( string, "%s", prefix );  
  if ( !strcmp( prefix, "line" ) ) {
    int x1, y1, x2, y2;
    if ( sscanf( string, "%s %d %d %d %d", prefix, &x1, &y1, &x2, &y2 ) != 5 )
      return 0;
    command->type = Line;
    command->args.line.x1 = x1;
    command->args.line.y1 = y1;
    command->args.line.x2 = x2;
    command->args.line.y2 = y2;
    return 1;
  }
  
  if ( !strcmp( prefix, "circle" ) ) {
    int x, y, radius;
    if ( sscanf( string, "%s %d %d %d", prefix, &x, &y, &radius ) != 4 )
      return 0;
    command->type = Circle;
    command->args.circle.x = x;
    command->args.circle.y = y;
    command->args.circle.radius = radius;
    return 1;
  }
  
  if ( !strcmp( prefix, "pen" ) ) {
    int r,g,b;
    if ( sscanf( string, "%s %d %d %d", prefix, &r, &g, &b ) != 4 )
      return 0;
    command->type = Pen;
    command->args.color.red = r;
    command->args.color.green = g;
    command->args.color.blue = b;
    return 1;
  }  
  if ( !strcmp( prefix, "fill" ) ) {
    int r,g,b;
    if ( sscanf( string, "%s %d %d %d", prefix, &r, &g, &b ) != 4 ) 
      return 0;
    command->type = Fill;
    command->args.color.red = r;
    command->args.color.green = g;
    command->args.color.blue = b;
    return 1;
  }
  
  if ( !strcmp( prefix, "quit" ) ) {
    command->type = Quit;
    return 1;
  }
  return 0;
}

/*
int main( int argc, char * argv[] ) {
  shell();
}
*/
