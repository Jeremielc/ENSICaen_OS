#ifndef _DRAWING_WIDGET_H_
#define _DRAWING_WIDGET_H_

#include <QWidget>
#include <QPicture>
#include <QPainter>
#include <QFile>
#include <list>
#include "DrawingCommands.h"

class DrawingWidget : public QWidget {
  Q_OBJECT
 public:
  DrawingWidget( QWidget * parent );
  ~DrawingWidget();
  
  void resizeEvent( QResizeEvent * event );
  void paintEvent( QPaintEvent * event );

  void line( int x1, int y1, int x2, int y2 );
  void circle( int x, int y, int radisu );
  void brush( int red, int green, int blue );
  void pen( int red, int green, int blue );
  void command( const DrawingCommand & );
  void saveFile( QFile & file );
  int count();

 signals:
  void resized( QString );

 public slots:
  void clear();
  
 private:

  std::list<DrawingCommand> _commands;
  int _primitives;
  QPixmap _logo;
};

#endif
