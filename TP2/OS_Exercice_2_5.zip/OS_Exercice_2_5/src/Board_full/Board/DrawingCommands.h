/**
 * @file   DrawingCommands.h
 * @author Sebastien Fourey <http://www.greyc.ensicaen.fr>
 * @date   Fev. 2012
 * 
 * @brief  Types utilisés par le prgramme Board pour décrire
 *         des opérations de dessin. Une commande est une 
 *         variable du type "DrawingCommand".
 * 
 */
#ifndef _DRAWING_COMMANDS_H_
#define _DRAWING_COMMANDS_H_

struct LineArgs {
  int x1;			/**< Colonne du premier point */
  int y1;			/**< Ligne du premier point */
  int x2;			/**< Colonne du second point */
  int y2;			/**< Ligne du second point */
};

struct CircleArgs {
  int x;			/**< Colonne du centre du cercle */
  int y;			/**< Ligne du centre du cercle */
  int radius;			/**< Rayon du cercle */
};

struct ColorArgs {
  int red;			/**< Composante rouge de la couleur */
  int green;			/**< Composante verte de la couleur */
  int blue;			/**< Composante bleue de la couleur */
};

enum CommandType { 
  Pen = 0,			/**< Changer la couleur de trait */
  Fill,				/**< Changer la couleur de remplissage */
  Line,				/**< Dessiner une ligne droite */
  Circle,			/**< Dessiner un cercle */
  Quit				/**< Fermer le programme de dessin */
};

/**
 * Structure de commandes de dessin. Un champs (type) donne
 * le type de la commande et un champ de type union donne les
 * argument de la commande.
 */
struct DrawingCommand {
  enum CommandType type;	/**< Type de commande */
  union { 
    struct LineArgs line;	/**< Arguments pour une ligne */
    struct CircleArgs circle;	/**< Arguments pour un cercle */
    struct ColorArgs color;	/**< Arguments pour une couleur (trait/remplissage) */
  } args;			/**< Arguments de la commande */
};

#endif /* !defined _DRAWING_COMMANDS_H_ */
