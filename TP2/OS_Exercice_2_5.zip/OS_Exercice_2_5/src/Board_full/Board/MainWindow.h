#ifndef _MAINWINDOW_WIDGET_H_
#define _MAINWINDOW_WIDGET_H_

#include <QMainWindow>
#include "DrawingWidget.h"

class MainWindow : public QMainWindow {
  Q_OBJECT
 public:
  MainWindow( bool readStdIn, QWidget * parent = 0 );
  void timerEvent( QTimerEvent * event );
  
 public slots:
  void onQuit(); 
  void onOpen(); 
  void onSave(); 
  void onAbout(); 
  void onResize( const QString & );
  void updateStatus();
 private:
  DrawingWidget * _drawingWidget;
};

#endif
