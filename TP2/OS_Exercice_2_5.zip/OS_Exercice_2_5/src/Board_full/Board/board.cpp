#include "MainWindow.h"
#include <QApplication>
#include "DrawingCommands.h"
#include "shell.h"
#include <iostream>
#include <fstream>
using namespace std;

#include <signal.h>

int main( int argc, char * argv[] )
{
  QApplication app( argc, argv );

  if ( ! strcmp( argv[ argc - 1 ], "-sample" ) ) {
    ofstream f("body.bin");
    DrawingCommand com;
    // Head
    com.type = Pen;
    com.args.color.red = 255;
    com.args.color.green = 0;
    com.args.color.blue = 0;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    com.type = Circle;
    com.args.circle.x = 80;
    com.args.circle.y = 50;
    com.args.circle.radius = 20;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    // Body
    com.type = Pen;
    com.args.color.red = 0;
    com.args.color.green = 0;
    com.args.color.blue = 255;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    com.type = Line;
    com.args.line.x1 = 80;
    com.args.line.y1 = 70;
    com.args.line.x2 = 80;
    com.args.line.y2 = 160;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    // Legs
    com.type = Line;
    com.args.line.x1 = 80;
    com.args.line.y1 = 160;
    com.args.line.x2 = 110;
    com.args.line.y2 = 210;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    com.type = Line;
    com.args.line.x1 = 80;
    com.args.line.y1 = 160;
    com.args.line.x2 = 50;
    com.args.line.y2 = 210;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    // Arms
    com.type = Line;
    com.args.line.x1 = 50;
    com.args.line.y1 = 100;
    com.args.line.x2 = 110;
    com.args.line.y2 = 100;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    // Mouth
    com.type = Line;
    com.args.line.x1 = 75;
    com.args.line.y1 = 60;
    com.args.line.x2 = 85;
    com.args.line.y2 = 60;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    // Eyes
    com.type = Circle;
    com.args.circle.x = 75;
    com.args.circle.y = 45;
    com.args.circle.radius = 3;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    com.type = Circle;
    com.args.circle.x = 85;
    com.args.circle.y = 45;
    com.args.circle.radius = 3;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    // Mouth corners
    com.type = Line;
    com.args.line.x1 = 88;
    com.args.line.y1 = 57;
    com.args.line.x2 = 85;
    com.args.line.y2 = 60;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    com.type = Line;
    com.args.line.x1 = 75;
    com.args.line.y1 = 60;
    com.args.line.x2 = 72;
    com.args.line.y2 = 57;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );
    // Noze
    com.type = Line;
    com.args.line.x1 = 80;
    com.args.line.y1 = 55;
    com.args.line.x2 = 80;
    com.args.line.y2 = 52;
    f.write( reinterpret_cast<const char*>(&com), sizeof( com ) );    
    
    f.close();
    exit( 0 );
  }

  if ( !strcmp( argv[ argc - 1 ], "-shell" ) ) {
    shell();
  }
  
  MainWindow * mainWindow;
  if ( ! strcmp( argv[ argc - 1 ], "-" ) ) {
    mainWindow =  new MainWindow( true, 0 );
    } else {
    mainWindow =  new MainWindow( false, 0 ); 
  }
  
  mainWindow->show();
  app.exec();
}


