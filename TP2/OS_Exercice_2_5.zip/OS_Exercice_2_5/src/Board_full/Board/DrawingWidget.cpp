#include "DrawingWidget.h"
#include <iostream>
#include <QPainter>
#include <QResizeEvent>

using namespace std;

DrawingWidget::DrawingWidget( QWidget * parent )
  :QWidget( parent ),
   _primitives( 0 ),
   _logo( ":/ensicaen.png", "PNG" )
{
  setAutoFillBackground(false);
  setAttribute( Qt::WA_OpaquePaintEvent );
  setMinimumWidth(320);
  setMinimumHeight(200);
}

DrawingWidget::~DrawingWidget()
{
}

void
DrawingWidget::paintEvent ( QPaintEvent * )
{
  QPixmap pixmap( size() );
  pixmap.fill( Qt::white );
  QPainter painter( &pixmap );  
  painter.setRenderHint(QPainter::Antialiasing); 
  painter.drawPixmap( width() - _logo.width() - 1,
		      height() - _logo.height() - 1,
		      _logo );
  list<DrawingCommand>::iterator ic = _commands.begin();
  list<DrawingCommand>::iterator end = _commands.end();
  while ( ic != end ) {
    switch ( ic->type ) {
    case Pen:
      painter.setPen( QColor( ic->args.color.red,
			      ic->args.color.green,
			      ic->args.color.blue ) );
      break;
    case Fill:
      painter.setBrush( QColor( ic->args.color.red,
				ic->args.color.green,
				ic->args.color.blue ) );
      break;
    case Line:
      painter.drawLine( ic->args.line.x1, ic->args.line.y1,
			ic->args.line.x2, ic->args.line.y2 );
      break;
    case Circle:
      painter.drawEllipse( ic->args.circle.x - ic->args.circle.radius,
			   ic->args.circle.y - ic->args.circle.radius,
			   2 * ic->args.circle.radius,
			   2 * ic->args.circle.radius );
      break;
    default:
      std::cout << "Unrecognized command\n";
    }
    ++ic;
  }
  painter.end();
  painter.begin( this );
  painter.drawPixmap( 0, 0, pixmap );
}

void
DrawingWidget::line( int x1, int y1, int x2, int y2 )
{
  DrawingCommand command;
  command.type = Line;
  command.args.line.x1 = x1;
  command.args.line.y1 = y1;
  command.args.line.x2 = x2;
  command.args.line.y2 = y2;
  DrawingWidget::command( command );
}

void
DrawingWidget::circle( int x, int y, int radius )
{
  DrawingCommand command;
  command.type = Circle;
  command.args.circle.x = x;
  command.args.circle.y = y;
  command.args.circle.radius = radius;
  DrawingWidget::command( command );
}

void
DrawingWidget::pen( int red, int green, int blue )
{
  DrawingCommand command;
  command.type = Pen;
  command.args.color.red = red;
  command.args.color.green = green;
  command.args.color.blue = blue;
  DrawingWidget::command( command );
}

void
DrawingWidget::brush( int red, int green, int blue )
{
  DrawingCommand command;
  command.type = Fill;
  command.args.color.red = red;
  command.args.color.green = green;
  command.args.color.blue = blue;
  DrawingWidget::command( command );
}

void
DrawingWidget::command( const DrawingCommand &  command )
{
  switch ( command.type ) {
  case Line:
    ++ _primitives;
    printf( "OK, I drew a line\n" );
    break;
  case Circle:
    ++ _primitives;
    printf( "OK, I drew a circle\n" );
    break;
  case Fill:
    printf( "OK, I changed the fill color\n" );
    break;
  case Pen:
    printf( "OK, I changed the pen color\n" );
    break;
  case Quit:
    break;
  }
  _commands.push_back( command );
  update(); 
  fflush(stdout);
}

void
DrawingWidget::clear()
{
  _primitives = 0;
  _commands.clear();
  update();
}

void
DrawingWidget::resizeEvent( QResizeEvent * event )
{
  emit resized( QString( "%1x%2" ).arg( event->size().width() ).arg( event->size().height() ) );
}

void
DrawingWidget::saveFile( QFile & file )
{
  list<DrawingCommand>::iterator it = _commands.begin();
  list<DrawingCommand>::iterator end = _commands.end();
  while ( it != end ) {
    file.write( reinterpret_cast<const char*>( & *it ), sizeof( *it ) );
    ++it;
  }
}

int
DrawingWidget::count() {
  return _primitives;
}
