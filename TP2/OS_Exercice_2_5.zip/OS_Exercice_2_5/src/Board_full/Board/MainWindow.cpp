#include <iostream>
#include "MainWindow.h"
#include <QApplication>
#include <QMenu>
#include <QMenuBar>
#include <QAction>
#include <QTimerEvent>
#include <QFileDialog>
#include <QStatusBar>
#include <QMessageBox>
#include "DrawingWidget.h"
#include <sys/time.h>
#include <sys/select.h>
#include <sys/types.h>
#include <unistd.h>



MainWindow::MainWindow( bool readStdIn, QWidget * parent )
  : QMainWindow( parent )
{
  QMenu * fileMenu = new QMenu( "&File", this );
  menuBar()->addMenu( fileMenu );

  QMenu * drawMenu = new QMenu( "&Draw", this );
  menuBar()->addMenu( drawMenu );

  QAction * loadAction = new QAction( "&Open", this );
  loadAction->setShortcut( QKeySequence::Open );
  connect( loadAction, SIGNAL( triggered(bool) ),
	   this, SLOT( onOpen() ) );
  fileMenu->addAction( loadAction );

  QAction * saveAction = new QAction( "&Save as...", this );
  saveAction->setShortcut( QKeySequence::Save );
  connect( saveAction, SIGNAL( triggered(bool) ),
	   this, SLOT( onSave() ) );
  fileMenu->addAction( saveAction );
  fileMenu->addSeparator();

  // loadAction->setEnabled( false );

  QAction * quitAction = new QAction( "&Quit", this );
  quitAction->setShortcut( QKeySequence::Quit );
  connect( quitAction, SIGNAL( triggered(bool) ),
	   this, SLOT( close() ) );
  connect( quitAction, SIGNAL( triggered(bool) ),
	   this, SLOT( onQuit() ) );
  fileMenu->addAction( quitAction );

  QAction * clearAction = new QAction( "&Clear", this );
  drawMenu->addAction( clearAction );

  QMenu * helpMenu = new QMenu( "&Help", this );
  menuBar()->addMenu( helpMenu );

  QAction * aboutAction = new QAction( "&About", this );
  connect( aboutAction, SIGNAL( triggered(bool) ),
	   this, SLOT( onAbout() ) );
  helpMenu->addAction( aboutAction );

  _drawingWidget = new DrawingWidget( this );
  connect( clearAction, SIGNAL( triggered(bool) ),
	   _drawingWidget, SLOT( clear() ) );
  connect( clearAction, SIGNAL( triggered(bool) ),
	   this, SLOT( updateStatus() ) );
  setCentralWidget( _drawingWidget );  
  connect( _drawingWidget, SIGNAL( resized( const QString & ) ),
	   this, SLOT( onResize( const QString & ) ) );
  setWindowTitle( "Board: a drawing board [640x480]" );

  statusBar()->show();

  if ( readStdIn )
    startTimer( 200 );
}

void
MainWindow::onQuit()
{
  std::cout << "Board has been closed.\n";
}

void
MainWindow::onAbout()
{
  QMessageBox::about( this, "About Board", "Board: A simple drawing panel.\n (C) S�bastien Fourey" );
}

void
MainWindow::onOpen()
{
  QString filename = QFileDialog::getOpenFileName( this,
						   QString(),
						   QString(),
						   "Drawing commands file (*.bin)",
						   0, 0 );
  if ( filename.isEmpty() ) return;
  QFile file( filename );
  file.open( QIODevice::ReadOnly );
  while ( file.isReadable() && !file.atEnd() ) {
    DrawingCommand command;
    file.read( reinterpret_cast<char*>(&command), sizeof(command) );
    _drawingWidget->command( command );
    updateStatus();
  }
}

void
MainWindow::onSave()
{
  QString filename = QFileDialog::getSaveFileName( this,
						   QString(),
						   QString(),
						   "Drawing commands file (*.bin)",
						   0, 0 );
  if ( filename.isEmpty() ) return;
  QFile file( filename );
  file.open( QIODevice::ReadWrite | QIODevice::Truncate );
  if ( file.isWritable() ) {
    _drawingWidget->saveFile( file );    
  }
  file.close();
}

void
MainWindow::timerEvent( QTimerEvent * e )
{
  fd_set ins;
  struct timeval timeout;
  timeout.tv_sec = 0;
  timeout.tv_usec = 0;
  FD_ZERO( &ins );
  FD_SET( 0, &ins );
  int ret = select( 1, &ins, NULL, NULL, &timeout );
  if ( ret  && FD_ISSET( 0, &ins ) ) { 
    DrawingCommand command;
    if ( 0 == read( 0, &command, sizeof( command ) ) ) {
      killTimer( e->timerId() );
    } else { 
      if ( command.type == Quit ) {
	std::cout << "OK, I quit!\n";
	qApp->quit();
      }
      _drawingWidget->command( command );
      updateStatus();
    }
  }
}

void
MainWindow::onResize( const QString & size )
{
  setWindowTitle( QString("Board: a drawing board [%1]").arg( size ) );
}

void
MainWindow::updateStatus()
{
  int n = _drawingWidget->count();
  switch ( n ) {
  case 0:
    statusBar()->showMessage( "Nothing on the board" );
    break;
  case 1:
    statusBar()->showMessage( "1 picture element" );
    break;
  default:
    statusBar()->showMessage( QString( "%1 picture elements ").arg( n ) );
    break;
  }
}
