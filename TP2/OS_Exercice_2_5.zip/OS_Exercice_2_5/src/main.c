/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 31 mai 2016, 17:19
 */

#include "headers/header.h"
#include "Board_full/Board/DrawingCommands.h"

int main(void) {
    int father_son_pipe[2];
    int son_father_pipe[2];
    if (pipe(father_son_pipe) == 1 || pipe(son_father_pipe) == 1) {
        perror("Pipes invalides\n");
    }

    char* output = (char*) malloc(BUFF_SIZE * sizeof (char));
    char* input = (char*) malloc(BUFF_SIZE * sizeof (char));
    clearBuffer(input);
    clearBuffer(output);

    pid_t pid = fork();

    if (pid == -1) {
        perror("Fork impossible\n");
    } else if (pid == 0) {
        close(father_son_pipe[1]);
        close(son_father_pipe[0]);

        dup2(father_son_pipe[0], STDIN_FILENO);
        dup2(son_father_pipe[1], STDOUT_FILENO);

        execl("/home/jeremie/Developpement/NetBeansProjects/OS_Exercice_2_5/src/Board_full/Board/board",
                "board", "-", NULL);
    } else {
        close(father_son_pipe[0]);
        close(son_father_pipe[1]);

        do {
            printf("shell_board : ");
            fgets(output, BUFF_SIZE, stdin);

            struct DrawingCommand* dCom = parseCommand(output);

            if (output[0] == 'q' && output[1] == 'u' && output[2] == 'i' && output[3] == 't') { //Detection de "quit"
                write(father_son_pipe[1], dCom, sizeof (dCom));
                read(son_father_pipe[0], input, BUFF_SIZE);
                
                free(dCom);
                break;
            }

            write(father_son_pipe[1], dCom, sizeof (dCom));
            read(son_father_pipe[0], input, BUFF_SIZE);

            printf("Board says : %s\n", input);

            clearBuffer(input);
            clearBuffer(output);
        } while (strcmp(output, "quit") != 0);
    }

    return EXIT_SUCCESS;
}

void clearBuffer(char* buff_out) {
    for (int i = 0; i < BUFF_SIZE; i++) {
        buff_out[i] = '\0';
    }
}

struct DrawingCommand* parseCommand(char* input) {
    char buff[10];
    int arg1, arg2, arg3, arg4;

    sscanf(input, "%s %d %d %d %d", buff, &arg1, &arg2, &arg3, &arg4);

    struct DrawingCommand* dCom = (struct DrawingCommand*) malloc (1 * sizeof(struct DrawingCommand));

    if (strcmp(buff, "line") == 0) {
        dCom->type = Line;
    } else if (strcmp(buff, "pen") == 0) {
        dCom->type = Pen;
    } else if (strcmp(buff, "fill") == 0) {
        dCom->type = Fill;
    } else if (strcmp(buff, "circle") == 0) {
        dCom->type = Circle;
    } else if (strcmp(buff, "quit") == 0) {
        dCom->type = Quit;
    }

    struct LineArgs lArgs;
    struct ColorArgs coArgs;
    struct CircleArgs ciArgs;

    switch (dCom->type) {
        case Line:
            lArgs.x1 = arg1;
            lArgs.y1 = arg2;
            lArgs.x2 = arg3;
            lArgs.y2 = arg4;

            dCom->args.line = lArgs;
            break;
        case Pen:
            coArgs.red = arg1;
            coArgs.green = arg2;
            coArgs.blue = arg3;

            dCom->args.color = coArgs;
            break;
        case Fill:
            coArgs.red = arg1;
            coArgs.green = arg2;
            coArgs.blue = arg3;

            dCom->args.color = coArgs;
            break;
        case Circle:
            ciArgs.x = arg1;
            ciArgs.y = arg2;
            ciArgs.radius = arg3;

            dCom->args.circle = ciArgs;
            break;
        case Quit:
            break;
        default:
            printf("Unknowm command\n");
            break;
    }

    return dCom;
}