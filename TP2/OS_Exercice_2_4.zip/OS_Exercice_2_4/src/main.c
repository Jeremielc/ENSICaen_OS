/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 31 mai 2016, 15:45
 */

#include "headers/header.h"

int main(void) {
    int tube_pere_fils[2];
    int tube_fils_pere[2];
    if (pipe(tube_pere_fils) == 1 || pipe(tube_fils_pere) == 1) {
        perror("Pipes invalides\n");
    }

    char* output = (char*) malloc(BUFF_SIZE * sizeof (char));
    char* input = (char*) malloc(BUFF_SIZE * sizeof (char));
    clearBuffer(input);
    clearBuffer(output);

    pid_t pid = fork();

    if (pid == -1) {
        perror("Fork impossible\n");
    } else if (pid == 0) {
        close(tube_pere_fils[1]);
        close(tube_fils_pere[0]);

        dup2(tube_pere_fils[0], STDIN_FILENO);
        dup2(tube_fils_pere[1], STDOUT_FILENO);

        execl("/usr/bin/bc", "bc", NULL, NULL);
    } else {
        close(tube_pere_fils[0]);
        close(tube_fils_pere[1]);

        do {
            printf("String to compute : ");
            fgets(output, BUFF_SIZE, stdin);

            if (output[0] == 'q' && output[1] == 'u' && output[2] == 'i' && output[3] == 't') { //Detection de "quit"
                write(tube_pere_fils[1], output, strlen(output));
                break;
            }

            write(tube_pere_fils[1], output, strlen(output));
            read(tube_fils_pere[0], input, strlen(output));

            printf("-> %s\n", input);
            
            clearBuffer(input);
            clearBuffer(output);
        } while (strcmp(output, "quit") != 0);
    }

    return EXIT_SUCCESS;
}

void clearBuffer(char* buff_out) {
    for (int i = 0; i < BUFF_SIZE; i++) {
        buff_out[i] = '\0';
    }
}