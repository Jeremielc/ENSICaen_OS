/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 2 juin 2016, 09:39
 */

#include "headers/header.h"

void p(int, int);
void v(int, int);

int main(int argc, char** argv) {
    key_t key = ftok(argv[0], 'E');
    int semid = semget(key, 2, IPC_CREAT | IPC_EXCL | 0600);
    if (semid == -1) {
        printf("%s\n", "Creation de semaphore impossible.");
        exit(0);
    }
    
    semctl(semid, 0, SETVAL, 1);
    semctl(semid, 1, SETVAL, 0);
    
    int count = 10;
    pid_t pid = fork();

    if (pid == -1) {
        printf("%s\n", "Fork impossible.");
    } else if (pid == 0) {
        while (count > 0) {
            p(semid, 1);
            printf("Je suis le processus fils de PID %d\n", getpid());
            count -= 1;
            v(semid, 0);
        }
    } else {
        while (count > 0) {
            p(semid, 0);
            printf("Je suis le processus pere de PID %d\n", getpid());
            count -= 1;
            v(semid, 1);
        }
    }

    semctl(semid, 0, IPC_RMID, 0);
    return (EXIT_SUCCESS);
}

void p(int semid, int num) {
    struct sembuf op;
    op.sem_flg = 0;
    op.sem_num = num;
    op.sem_op = -1;
    
    semop(semid, &op, 1);
}

void v(int semid, int num) {
    struct sembuf op;
    op.sem_flg = 0;
    op.sem_num = num;
    op.sem_op = 1;
    
    semop(semid, &op, 1);
}