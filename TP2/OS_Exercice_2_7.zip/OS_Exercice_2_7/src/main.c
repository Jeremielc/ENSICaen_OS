/*
 * File:   main.c
 * Author: jeremie
 *
 * Created on 3 juin 2016, 09:39
 */

#include "headers/header.h"

int main(int argc, char** argv) {
    key_t semKey = ftok(argv[0], 'E');
    int semid = semget(semKey, 7, IPC_CREAT | IPC_EXCL | 0600);
    if (semid == -1) {
        printf("%s\n", "Creation de semaphore impossible.");
        exit(0);
    }

    semctl(semid, 0, SETVAL, 0);
    semctl(semid, 1, SETVAL, 0);
    semctl(semid, 2, SETVAL, 0);
    semctl(semid, 3, SETVAL, 0);
    semctl(semid, 4, SETVAL, 0);

    semctl(semid, 5, SETVAL, 1); //Gestion de l'acces à la ressource partagée
    semctl(semid, 6, SETVAL, 1); //Gestion de l'acces à l'affichage.

    int shmKey = ftok(argv[0], 'J');
    int shmid = shmget(shmKey, 6 * sizeof (char), IPC_CREAT | 0600);
    if (shmid == -1) {
        printf("%s\n", "Creation de shmem impossible.");
        exit(0);
    }

    //Obtention des informations
    printf("semid : %d\n", semid);
    printf("shmid : %d\n\n", shmid);
    fflush(stdout);

    char* philStatus = shmat(shmid, NULL, SHM_R | SHM_W);
    for (int i = 0; i < 5; i++) {
        philStatus[i] = THINK;
    }
    philStatus[5] = '\0';

    pid_t pid;

    for (int i = 0; i < 5; i++) {
        pid = fork();
        srand(time(NULL) + getpid());

        if (pid == -1) {
            printf("%s\n", "Fork impossible.");
            exit(-1);
        } else if (pid == 0) {
            int count = 3;

            while (count > 0) {
                thinkAskEatRepeat(semid, i, philStatus);
                count--;
            }

            exit(1);
        }
    }

    for (int i = 0; i < 5; i++) {
        wait(NULL);
    }

    semctl(semid, 0, IPC_RMID, 0);
    shmctl(shmid, IPC_RMID, NULL);
    return (EXIT_SUCCESS);
}

void Probeer(int semid, int num) {
    struct sembuf op;
    op.sem_flg = 0;
    op.sem_num = num;
    op.sem_op = -1;

    semop(semid, &op, 1);
}

void Verhoog(int semid, int num) {
    struct sembuf op;
    op.sem_flg = 0;
    op.sem_num = num;
    op.sem_op = 1;

    semop(semid, &op, 1);
}

void printPhilState(int semid, int philNum, char* philStatus) {
    Probeer(semid, 6);
    for (int i = 0; i < 5; i++) {
        switch (philStatus[i]) {
            case THINK:
                printf("[%s] Philosophe %d %s\n", philStatus, i, "pense.");
                break;
            case ASK:
                printf("[%s] Philosophe %d %s\n", philStatus, i, "demande à manger.");
                break;
            case EAT:
                printf("[%s] Philosophe %d %s\n", philStatus, i, "mange.");
                break;
        }
        fflush(stdout);
    }

    printf("\n");
    Verhoog(semid, 6);
}

void checkIfPhilCanEat(int semid, int philNum, char* philStatus) {
    if (philStatus[(philNum + 4) % 5] != EAT) {
        if (philStatus[(philNum + 1) % 5] != EAT) {
            if (philStatus[philNum] == ASK) {
                Verhoog(semid, philNum);
            }
        }
    }
}

void setPhilState(char* philStatus, int philNum, char state) {
    switch (state) {
        case THINK:
            philStatus[philNum] = THINK;
            break;
        case ASK:
            philStatus[philNum] = ASK;
            break;
        case EAT:
            philStatus[philNum] = EAT;
            break;
        default:
            break;
    }
}

void think(int semid, int philNum, char* philStatus) {
    int timeThinking = rand() % 3 + 1;

    Probeer(semid, 5);
    setPhilState(philStatus, philNum, THINK);
    Verhoog(semid, 5);

    sleep(timeThinking);
}

void ask(int semid, int philNum, char* philStatus) {
    Probeer(semid, 5);
    setPhilState(philStatus, philNum, ASK);

    checkIfPhilCanEat(semid, philNum, philStatus);
    Verhoog(semid, 5);
}

void eat(int semid, int philNum, char* philStatus) {
    Probeer(semid, philNum);
    int timeEating = rand() % 3 + 1;

    Probeer(semid, 5);
    setPhilState(philStatus, philNum, EAT);
    Verhoog(semid, 5);

    sleep(timeEating);

    Probeer(semid, 5);
    setPhilState(philStatus, philNum, THINK);

    checkIfPhilCanEat(semid, (philNum + 4) % 5, philStatus);
    checkIfPhilCanEat(semid, (philNum + 1) % 5, philStatus);
    Verhoog(semid, 5);
}

void thinkAskEatRepeat(int semid, int philNum, char* philStatus) {
    think(semid, philNum, philStatus);
    printPhilState(semid, philNum, philStatus);

    ask(semid, philNum, philStatus);
    printPhilState(semid, philNum, philStatus);

    eat(semid, philNum, philStatus);
    printPhilState(semid, philNum, philStatus);
}