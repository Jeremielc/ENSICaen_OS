/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 30 mai 2016, 16:32
 */

#include "headers/header.h"

int main(int argc, char** argv) {
    char* pipeName = argv[1];
    int pid_producer, pid_consummer;

    pid_producer = fork();
    if (pid_producer == 0) {
        producer(pipeName);
        exit(0);
    } else {
        pid_consummer = fork();
        if (pid_consummer == 0) {
            consummer(pipeName);
            exit(1);
        } else {

        }
    }

    while (wait(NULL) > -1) {

    }

    return (EXIT_SUCCESS);
}

void producer(char* pipeName) {
    printf("producer\n");
    int count = 10;
    char* character = (char*) malloc(1 * sizeof(char));

    int fileno = open(pipeName, O_WRONLY);
    int fifo = mkfifo(pipeName, 0666);
    if (fileno == -1) {
        printf("Erreur à l'ouverture du pipe.\n");
        exit(-1);
    }
    
    while (count > 0) {
        *character = 'A' + rand() % 26;
        int writed;
        do {
            writed = write(fileno, character, 1);
        } while (writed == -1);
        
        *character = 'A';
        count -= 1;
        sleep(1);
    }
    
    free(character);
}

void consummer(char* pipeName) {
    printf("consummer\n");
    int count = 10;
    char* buffer = (char*) malloc(1 * sizeof(char));

    int fileno = open(pipeName, O_RDONLY);
    int fifo = mkfifo(pipeName, 0666);
    if (fileno == -1) {
        printf("Erreur à l'ouverture du pipe.\n");
        exit(-1);
    }
    
    while (count > 0) {
        int readed = read(fileno, buffer, 1);
        if (readed != -1) {
            printf("%s\n", buffer);
            count -= 1;
        }
    }
    
    free(buffer);
}