/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 30 mai 2016, 16:32
 */

#include "headers/header.h"

int main(int argc, char** argv) {
    char* pipeName = argv[1];
    printf("Producer\n");
    char* character = (char*) malloc(1 * sizeof(char));
    srand(time(NULL));

    int fileno = open(pipeName, O_WRONLY);
    int fifo = mkfifo(pipeName, 0666);
    if (fileno == -1) {
        printf("Erreur à l'ouverture du pipe.\n");
        exit(-1);
    }
    
    while (1) {
        *character = 'A' + rand() % 26;
        int writed;
        do {
            writed = write(fileno, character, 1);
        } while (writed == -1);
        
        *character = 'A';
        sleep(1);
    }
    
    free(character);
    close(fileno);
    
    return EXIT_SUCCESS;
}