/* 
 * File:   main.c
 * Author: jeremie
 *
 * Created on 30 mai 2016, 16:32
 */

#include "headers/header.h"

int main (int argc, char** argv) {
    char* pipeName = argv[1];
    printf("consummer\n");
    char* buffer = (char*) malloc(1 * sizeof(char));
    char* lastChar = (char*) malloc(1 * sizeof(char));
    srand(time(NULL));

    int fileno = open(pipeName, O_RDONLY);
    int fifo = mkfifo(pipeName, 0666);
    if (fileno == -1) {
        printf("Erreur à l'ouverture du pipe.\n");
        exit(-1);
    }
    
    lastChar[0] = 'a';
    int readed, sameChar = 0;
    do {
        readed = read(fileno, buffer, 1);
        if (readed != -1) {
            printf("%s\n", buffer);
        }
        
        if (strcmp(lastChar, buffer) == 0) {
            sameChar = 1;
        } else {
            strcpy(lastChar, buffer);
        }
    } while (sameChar != 1);
    
    free(buffer);
    close(fileno);
    
    return EXIT_SUCCESS;
}